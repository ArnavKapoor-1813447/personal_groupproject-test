document.addEventListener('DOMContentLoaded', () => {
    // Smooth scrolling when clicking on sidebar links
    const sidebarLinks = document.querySelectorAll('#sidebar a');

    sidebarLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();

            const targetId = link.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);

            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 50, // Adjust this value according to your layout
                    behavior: 'smooth'
                });
            }
        });
    });
});