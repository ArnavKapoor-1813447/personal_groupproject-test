function toggleMenu() {
  const navLinksSub = document.getElementById("nav-links-sub");
  navLinksSub.classList.toggle("show");
}

document.querySelector(".fa-bars").addEventListener("click", toggleMenu);